import { View, Text } from "react-native";

const Questao3 = ({cor}) => {

    return(
      <View>
        <Text style={{color: cor}}>Modselagem Tridimensional</Text>
        <Text style={{color: cor}}>IHC</Text>
        <Text style={{color: cor}}>Direção de Arte</Text>
        <Text style={{color: cor}}>Avaliaçãop em IHC</Text>
        <Text style={{color: cor}}>Semióticca</Text>
      </View>
    )

}

export default Questao3